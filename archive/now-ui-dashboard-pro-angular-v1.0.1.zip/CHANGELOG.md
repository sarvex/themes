## [1.0.1] - 2019-04-08
### Changes
- perfect scrollbar issue
- added fixed plugin

## [1.0.0] - 2019-02-08
### Initial Release
