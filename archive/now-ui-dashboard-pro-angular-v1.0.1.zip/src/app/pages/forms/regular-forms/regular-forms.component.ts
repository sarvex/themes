import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-regular-forms",
  templateUrl: "./regular-forms.component.html",
  styleUrls: ["./regular-forms.component.css"]
})
export class RegularFormsComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
