import EditProfileForm from "./Dashboard/Pages/UserProfile/EditProfileForm.vue";
import UserCard from "./Dashboard/Pages/UserProfile/UserCard.vue";

export { EditProfileForm, UserCard };
