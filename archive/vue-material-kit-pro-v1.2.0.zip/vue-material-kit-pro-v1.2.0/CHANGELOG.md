# Change Logs

## [1.2.0] 2019-08-15
### Updates
- Vue Material updated to the latest release `v1.0.0-beta-11`
- Vuejs updated to the latest release `v2.6.10`
- Updated the rest of dependencies to the latest release

## [1.1.0] 2019-02-12
### Updates
- Updated all dependencies to the latest version

## [1.0.1] 2019-01-21
### Improvements
- added `eslint-plugin-vue` to our `package.json` dependencies to make the eslint working properly in the product

## [1.0.0] 2019-01-17
### Initial Release
