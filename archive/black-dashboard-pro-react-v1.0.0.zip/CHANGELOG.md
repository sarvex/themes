## [1.0.0] 2019-01-14
### Original Release
- Added Reactstrap as base framework
- Added design from Black Dashboard PRO by Creative Tim
