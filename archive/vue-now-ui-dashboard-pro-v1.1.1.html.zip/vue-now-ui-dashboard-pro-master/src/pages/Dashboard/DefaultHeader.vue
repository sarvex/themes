<template>
  <div class="panel-header panel-header-sm">
  </div>
</template>
<script>
export default {};
</script>
<style>
</style>
