# Change Log

## [1.0.1] 2018-08-17

### Bug fixes
- Fix css issue (not displaying header text) #1
- Add vue-template-compiler to devDependencies
- Update dependencies

## [1.0.0] 2018-08-08
### Stable Original Release
