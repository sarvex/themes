<template>
    <div class="wrapper starter-page d-flex justify-content-center align-items-center">
        Hello World
    </div>
</template>
<script>
  export default {}
</script>
<style scoped>
    .starter-page {
        min-height: calc(100vh - 79px)
    }
</style>
