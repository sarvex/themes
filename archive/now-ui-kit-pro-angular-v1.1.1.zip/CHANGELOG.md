# Change Log
## [1.1.1] 2019-03-11
### Changes
- update to Angular 7
- update all the dependencies to match the version of Angular

## [1.1.0] 2018-10-17
### Changes
- update to Angular 6
- update all the dependencies to match the version of Angular
- fixed the design errors

## [1.0.2] 2018-05-21
### Changes
- changed the GitHub repository

## [1.0.1] 2018-03-01
### Fixes
- optimised size of images
- fixed links in static documentation

## [1.0.0] 2018-02-15
### Original Release
