import {Component, OnInit } from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'fullscreen-map-cmp',
    templateUrl: 'fullscreenmap.component.html'
})

export class FullScreenMapsComponent implements OnInit{
    ngOnInit(){
	}
}
