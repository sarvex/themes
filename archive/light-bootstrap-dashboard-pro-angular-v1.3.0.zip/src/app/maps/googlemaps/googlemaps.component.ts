import { Component, OnInit } from '@angular/core';


@Component({
    moduleId: module.id,
    selector: 'vector-maps-cmp',
    templateUrl: './googlemaps.component.html'
})

export class GoogleMapsComponent implements OnInit{

    ngOnInit(){


    }
}
