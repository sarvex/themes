## [1.3.0] - 2019-08-20
### Updates
- update to Angular 8
- update all dependencies to match Angular 8 version
- update to bootstrap 4.3.1
- update the scss files to match the HTML version
- added useHash
### Bug Fixing
- fixed errors occurred with the updates
### Changes
- changed the margin-top of datepicker
- changed the navbar structure
- changed the product to fix the design errors because of the scss files update

## [1.2.0] 2018-08-20
### Changes
 - update to Angular 6
 - update dependencies

## [1.1.1] 2018-05-22
### Changes
 - changed the GitHub repository

## [1.1.0] 2018-02-22
### Changes
 - update from Angular 4.4.6 to 5.2.5
 - update ng-bootstrap to stable version 1.0.0

## [1.0.1] 2017-12-18
### Changes
 - added angular logo
 - added button for documentation
 - changed price from buy buttons

## [1.0.0] 2017-12-15
### Original Release
 
