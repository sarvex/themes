import {Component, OnInit } from '@angular/core';

declare var google:any;

@Component({
    moduleId: module.id,
    selector: 'fullscreen-map-cmp',
    templateUrl: 'fullscreenmap.component.html'
})

export class FullScreenMapsComponent implements OnInit{
    ngOnInit(){
	}
}
