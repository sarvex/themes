import { Component } from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'timeline-cmp',
    templateUrl: 'timeline.component.html'
})

export class TimelineComponent{}
