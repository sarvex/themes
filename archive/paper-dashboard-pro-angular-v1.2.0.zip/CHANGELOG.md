## [1.2.0] - 2019-06-19
### Updates
- update to Angular 8
- update all dependencies to match Angular 8 version
- added useHash
### Bug Fixing
- fixed errors occurred with the updates
- fixed the function for removing the footer for fullscreen map
- fixed the issue #19
- fixed the issue #29
- browser console error
```
href="#pablo" -> href="javascript:void(0)"
href="#"      -> href="javascript:void(0)"
```
### Changes
- changed the margin-top of datepicker
- changed the imports for JwBootstrapSwitchNg2Module, Swal

## [1.1.0] 2018-12-05
### Fixes
- updated to Bootstrap 4
- updated to Angular 6
- added online documentation
- changed the datepicker

## [1.0.1] 2017-12-05
### Fixes
- update package.json
- fixed checkboxes in regular forms
- fixed wizard

## [1.0.0] 2017-06-27
### Initial Release
